package resoluciónTaller;
public class CuartoPunto {

	public static void main(String[] args) {
		//Cuarto punto
			int min = 1;
			int max = 6;
			
			int d1 = (int) Math.floor(Math.random() * (max - min + 1) ) + min;
			int d2 = (int) Math.floor(Math.random() * (max - min + 1) ) + min;
			
			int puntosH=0;
			int puntosM=0;
			int suma=d1+d2;
			
			if  (d1==d2) {
				puntosH=puntosH+2;
				System.out.print("Los dos dados son iguales sumas dos puntos");
			}
			
			if (!(d1==d2) && suma>5 && suma%2==0) {
				puntosH=puntosH+1;
				System.out.print("Sumas un punto");
			}
			
			
			if (!(d1==d2) && suma<=5 && suma%2==0) {
				puntosM=puntosM+1;
				System.out.print("La maquina suma un punto");
				}
	
			if (!(d1==d2) && suma<5 && !(suma%2==0)) {
				puntosH=puntosH+1;
				System.out.print("Sumas un punto");
				}
			
			if (!(d1==d2) && suma>=5 && !(suma%2==0)) {
				puntosM=puntosM+1;
				System.out.print("La maquina suma un punto");
				}
			System.out.print("\n"+"Puntos Maquina: "+puntosM
							+"\n"+"Puntos Humano: "+puntosH);
			
	}

}
