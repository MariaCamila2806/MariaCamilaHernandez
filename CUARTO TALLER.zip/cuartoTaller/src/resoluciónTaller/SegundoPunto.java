package resoluciónTaller;
import javax.swing.JOptionPane;
public class SegundoPunto {

	public static void main(String[] args) {
		//Segundo punto
		String a= JOptionPane.showInputDialog("Cuestionario"
				+"\n"+"Responda con honestidad a las siguientes preguntas de si o no"
				+"\n"+ "Escriba 1 para sí y 2 para no"
				+"\n"+"1) ¿Tardas en contestar mensajes?");
		int ans = Integer.parseInt(a);
		
		switch(ans) {
			case 1:
				String b= JOptionPane.showInputDialog("Cuestionario"
						+"\n"+"Responda con honestidad a las siguientes preguntas de si o no"
						+"\n"+ "Escriba 1 para sí y 2 para no"
						+"\n"+"2) ¿Tienes mascotas?");
				int ans2 = Integer.parseInt(b);
					switch(ans2) {
						case 1:
							String c= JOptionPane.showInputDialog("Cuestionario"
									+"\n"+"Responda con honestidad a las siguientes preguntas de si o no"
									+"\n"+ "Escriba 1 para sí y 2 para no"
									+"\n"+"3) ¿Te gusta el brocoli?");
							int ans3 = Integer.parseInt(c);
								switch (ans3) {
									case 1:
										String d= JOptionPane.showInputDialog("Cuestionario"
												+"\n"+"Responda con honestidad a las siguientes preguntas de si o no"
												+"\n"+ "Escriba 1 para sí y 2 para no"
												+"\n"+"4) ¿Tienes pareja?");
										int ans4 = Integer.parseInt(d);
											switch(ans4) {
												case 1:
													String e= JOptionPane.showInputDialog("Cuestionario"
															+"\n"+"Responda con honestidad a las siguientes preguntas de si o no"
															+"\n"+ "Escriba 1 para sí y 2 para no"
															+"\n"+"5) ¿Has estado en la carcel?");
													int ans5 = Integer.parseInt(e);
														switch(ans5) {
															case 1:
																JOptionPane.showMessageDialog(null,"Cinco preguntas positivas");
																break;
															case 2:
																JOptionPane.showMessageDialog(null,"Cuatro preguntas positivas");
																break;
														}
												case 2:
													JOptionPane.showMessageDialog(null,"Tres preguntas positivas");
													break;
											}
									case 2:
										JOptionPane.showMessageDialog(null,"Dos preguntas positivas");
										break;
								}
						case 2:
							JOptionPane.showMessageDialog(null,"Una pregunta positiva");
							break;
				}
			case 2: 
				JOptionPane.showMessageDialog(null,"Cero preguntas positivas");
				break;
		}
	}

}
