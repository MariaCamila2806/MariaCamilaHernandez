package resoluciónTaller;
import javax.swing.JOptionPane;
public class PrimerPunto {

	public static void main(String[] args) {
		// Primer punto
			String x=JOptionPane.showInputDialog("Calculadora"
					+"\n"+"Ingresa la opción correspondiente a la operación que desee realizar: "
					+"\n"+"1 para suma"+"\n"+"2 para resta"+"\n"+"3 para multiplicación"+"\n"+"4 para división");
			int option = Integer.parseInt(x);
			
			String y=JOptionPane.showInputDialog("Calculadora"
					+"\n"+"Ingresa el primer numero:");
			int  n1= Integer.parseInt(y);
			
			String z=JOptionPane.showInputDialog("Calculadora"
					+"\n"+"Ingresa el segundo numero:");
			int n2 = Integer.parseInt(z);
			
			switch (option) {
				case 1:
					double ans=n1+n2;
					JOptionPane.showMessageDialog(null,"La suma de "+n1+" más "+n2+" es igual a "+ans);
					break;
				case 2:
					double ans2=n1-n2;
					JOptionPane.showMessageDialog(null,"La resta de "+n1+" menos "+n2+" es igual a "+ans2);
					break;
				case 3:
					double ans3=n1*n2;
					JOptionPane.showMessageDialog(null,"La multiplicación de "+n1+" por "+n2+" es igual a "+ans3);
					break;
				case 4:
					double ans4=n1/n2;
					JOptionPane.showMessageDialog(null,"La división de "+n1+" entre "+n2+" es igual a "+ans4);
					break;
			}
			

	}

}
