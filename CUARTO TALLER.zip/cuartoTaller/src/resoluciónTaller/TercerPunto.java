package resoluciónTaller;

import javax.swing.JOptionPane;

public class TercerPunto {

	public static void main(String[] args) {
		//Tercer punto
			String figura=JOptionPane.showInputDialog("CALCULADORA DE AREAS DE FIGURAS" 
					+ "\n" + "Ingresa el numero correspondiente a la figura que desees"
					+ "\n" + "1 para Triangulo"+ "\n" +"2 para Rectangulo"+ "\n" +"3 para Cuadrado"
					+ "\n" +"4 para rombo"+ "\n" +"5 para Circulo") ;
					int opcion = Integer.parseInt(figura);
			switch(opcion) {
				case 1: 
					String altura=JOptionPane.showInputDialog("CALCULADORA DE AREAS DE FIGURAS" 
							+ "\n" +"Has escogido triangulo, ingresa la altura en m del triangulo:");
					double h = Double.parseDouble(altura);
					
					String base=JOptionPane.showInputDialog("CALCULADORA DE AREAS DE FIGURAS" 
							+ "\n" +"Ahora ingresa la base en m del triangulo:");
					double b = Double.parseDouble(base);
					
					double ans=(h*b)/2;
					JOptionPane.showMessageDialog(null,"El area de tu triangulo es: "+ans+" metros cuadrados");
					
				case 2: 
					String largo=JOptionPane.showInputDialog("CALCULADORA DE AREAS DE FIGURAS" 
							+ "\n" +"Has escogido rectangulo, ingresa el largo en m del rectangulo:");
					double l = Double.parseDouble(largo);
					
					String alto=JOptionPane.showInputDialog("CALCULADORA DE AREAS DE FIGURAS" 
							+ "\n" +"Ahora ingresa el alto en m del rectangulo:");
					double a = Double.parseDouble(alto);
					
					double ans2=a*l;
					JOptionPane.showMessageDialog(null,"El area de tu rectangulo es: "+ans2+" metros cuadrados");
					
				case 3: 
					String lado=JOptionPane.showInputDialog("CALCULADORA DE AREAS DE FIGURAS" 
							+ "\n" +"Has escogido cuadrado, ingresa la longitud de un lado en m del cuadrado:");
					double la = Double.parseDouble(lado);
					double ans3=la*la;
					JOptionPane.showMessageDialog(null,"El area de tu cuadrado es: "+ans3+" metros cuadrados");
				
				case 4: 
					String diagonalmenor=JOptionPane.showInputDialog("CALCULADORA DE AREAS DE FIGURAS" 
							+ "\n" +"Has escogido rombo, ingresa la longitud de la diagonal menor en m del rombo:");
					double dm = Double.parseDouble(diagonalmenor);
					
					String diagonalmayor=JOptionPane.showInputDialog("CALCULADORA DE AREAS DE FIGURAS" 
							+ "\n" +"Ahora ingresa la longitud de la diagonal mayor en m del rombo:");
					double Dma = Double.parseDouble(diagonalmayor);
					
					double ans4=(dm*Dma)/2;
					JOptionPane.showMessageDialog(null,"El area de tu rectangulo es: "+ans4+" metros cuadrados");
					
				case 5:
					String radio = JOptionPane.showInputDialog("CALCULADORA DE AREAS DE FIGURAS" 
							+ "\n" +"Has escogido circulo, ingresa la longitud del radio en m del circulo:");
					double r=Double.parseDouble(radio);
					final double pi=3.14;
					double ans5=pi*Math.pow(r, 2);
					JOptionPane.showMessageDialog(null,"El area de tu circulo es: "+ans5+" metros cuadrados");
			}

	}

}
